# My Practice Repo

Repository latihan sederhana: Flask app kecil + pytest + GitHub Actions CI.
